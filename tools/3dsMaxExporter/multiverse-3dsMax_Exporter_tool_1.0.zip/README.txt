MULTIVERSE 3DS MAX EXPORT TOOL
Copyright 2007 The Multiverse Network, Inc.

To install the tool:

1. Quit 3ds Max.

2. Place the Multiverse-tools.ms file in the Scripts\Startup directory of the 
in your 3ds Max install directory.  By default, this directory is
C:\Program Files\Autodesk\3dsMax8\Scripts\Startup.

3. Restart 3ds Max.

Documentation is online at http://update.multiverse.net/wiki/index.php/Using_the_3ds_Max_Export_Tool.

